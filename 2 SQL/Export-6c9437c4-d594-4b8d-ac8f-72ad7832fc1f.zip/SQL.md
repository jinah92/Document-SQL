# SQL - 기본

Class: SQL
Created: Mar 17, 2020 10:33 PM
Reviewed: No

## 1. 관계형 데이터베이스

---

- 릴레이션과 릴레이션의 조인 연산을 통해서 합집합, 교집합, 차집합을 생성
- 특징 - 릴레이션을 사용한 집합 연산, 관계 연산

### 집합 연산

- 합집합(Union) : 두 개의 일레이션을 하나로 합침 (행의 중복 X)
- 차집합(Difference) : A 릴레이션 - B 릴레이션
- 교집합(Intersection) : 공통된 것을 조회
- 곱집합(Cartesian product) : 각 릴레이션에 존재하는 모든 것을 조회

### 관계 연산

- 선택 연산(Selection) : 조건에 맞는 행만을 조회
- 투영 연산(Projection) : 조건에 맞는 속성만을 조회
- 결합 연산(Join) : 여러 릴레이션의 공통된 속성을 사용 ⇒ 새로운 릴레이션 생성
- 나누기 연산(Division) : 기준에서 나누는 릴레이션에서 가지고 있는 속성과 동일한 값을 가지는 행을 추출하고, 나누는 릴레이션의 속성을 삭제/ 중복된 행 제거

## 2. SQL 종류

---

- 관계형 데이터베이스에 대해서 데이터의 구조를 정의, 데이터 조작, 데이터 제어 등을 할 수 있는 절차형 언어

### 종류

1. DDL : 관계형 데이터베이스의 구조를 정의 
    - Create, Alter, Drop, Rename
2. DML : 데이터를 입력, 수정, 삭제, 조회
    - Insert, Update, Delete, Select
3. DCL : 사용자에게 권한을 부여 또는 회수
    - Grant, Revoke
4. TCL : 트랜잭션 제어
    - Commit, Rollback

**트랜잭션의 특징**
1) 원자성(Atomicity) : All or Nothing 을 수행
2) 일관성(Consistency) : 트랜잭션 실행 후에도 일관성을 유지
3) 고립성(Isolation) : 부분적인 실행결과를 다른 트랜잭션이 볼 수 없음
4) 연속성(Durability) : 실행을 성공적으로 완료하면, 영구적으로 결과 보장

SQL문의 실행 순서
1) 파싱 : 문법을 확인하고 구문분석, 구문분석한 SQL문은 Library Cache에 저장
2) 실행 : 옵티마이저가 수립한 실행 계획에 따라 SQL문을 실행
3) 인출(Fetch) : 데이터를 읽어서 전송